package com.mycompany.student_management_system;


/*
 * for queue data structure we will use singly linked list
 * */
public class Queue<T>
{
    private node front = null ;
    private node rear = null ;
    private int size = 0 ;
    class node
    {
        T data ;
        node next ;

        public node(T data)
        {
            this.data = data ;
            this.next = null ;
        }
    }
    public void Enqueue(T key)
    {
        node n = new node(key) ;
        if(front==null && rear==null )
        {
            front = n ;
            rear = n ;
            size++ ;
        }
        else
        {

            rear.next = n ;
            rear = n ;
            size++ ;
        }
    }
    public T Dequeue()
    {
        T key = front.data ;
        front =  front.next;
        size-- ;
        if(size==0)
        {
            front = null ;
            rear = null ;
        }
        return key ;
    }
    public boolean isEmpty()
    {
        if(front==null && rear==null) return true ;
        else return false ;
    }
    public T peek()
    {
        return front.data;
    }
    public void clear()
    {
        front = null ;
        rear = null ;
        size = 0 ;
    }
    public int size()
    {
        return size ;
    }
    public void traversal()
    {
        node frontt = front ;
        while(frontt!=null)
        {
            System.out.println(frontt.data);
            frontt = frontt.next ;
        }
    }
}
class Question_4
{
    public static void main(String[] args) {
        Queue<Integer> q = new Queue<Integer>() ;
        System.out.println("The isEmpty Operation : "+q.isEmpty());
        q.Enqueue(5);
        q.Enqueue(4);
        q.Enqueue(3);
        q.Enqueue(2);
        q.Enqueue(1);
        q.Enqueue(0);
        q.traversal();
        System.out.println("The Enqueue Operations : "+q.Dequeue());
        q.traversal();
        System.out.println("Peek Element "+q.peek());
        System.out.println("The Size of the Queue is "+q.size());
        System.out.println("The isEmpty Operation : "+q.isEmpty());
        System.out.println("Clear Method : ");
        q.clear();
        System.out.println("The isEmpty Operation : "+q.isEmpty());
    }
}
